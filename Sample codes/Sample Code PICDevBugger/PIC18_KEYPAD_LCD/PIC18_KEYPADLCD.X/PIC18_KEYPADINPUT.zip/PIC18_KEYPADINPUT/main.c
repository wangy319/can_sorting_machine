/*
 * File:   main.c
 * Author: True Administrator
 *
 * Created on July 18, 2016, 12:11 PM
 */


#include <xc.h>
#include <stdio.h>
#include "configBits.h"
#include "constants.h"
#include "lcd.h"


const char keys[] = "123A456B789C*0#D"; 

void main(void) {
    OSCCON = 0xF2;  //8Mhz
    TRISC = 0x00;
    TRISD = 0x00;   //All output mode
    TRISB = 0xFF;   //All input mode
    LATB = 0x00; 
    LATC = 0x00;
    ADCON0 = 0x00;  //Disable ADC
    ADCON1 = 0xFF;  //Set PORTB to be digital instead of analog default  
    initLCD();
    
    while(1){
        while(PORTBbits.RB1 == 0){
        }
        unsigned char keypress = (PORTB & 0xF0)>>4;
        while(PORTBbits.RB1 == 1){
        }
        Nop();  //Apply breakpoint here because of compiler optimizations
        Nop();
        unsigned char temp = keys[keypress];
        putch(temp);   
    }
    
    return;
}
